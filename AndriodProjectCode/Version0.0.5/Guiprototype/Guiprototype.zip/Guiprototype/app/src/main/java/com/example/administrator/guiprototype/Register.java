package com.example.administrator.guiprototype;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by Administrator on 12/3/2017.
 */

public class Register extends AppCompatActivity implements View.OnClickListener{
    Button bnext;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bnext = (Button) findViewById(R.id.next);
        bnext.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.next:
                startActivity(new Intent(this,AddDevice.class));
                break;

        }

    }
}
